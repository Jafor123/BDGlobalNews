from django.contrib import admin
from App_Author.models import *
# Register your models here.

admin.site.register(EditorList)

from django.contrib import admin
from App_News.models import *
# Register your models here.
admin.site.register(Category)
admin.site.register(Categoryapply)
admin.site.register(Subcategoryapply)
admin.site.register(Sliderimage)
admin.site.register(Subcategory)
admin.site.register(News)
admin.site.register(Comment)
admin.site.register(UserVerify)
